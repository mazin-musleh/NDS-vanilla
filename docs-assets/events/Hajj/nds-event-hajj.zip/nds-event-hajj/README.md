# Hajj — NDS event pack

Drop-in theme for the National Design System. Copy this folder into your own
assets directory, then add two lines to your shared `<head>`, after the NDS
stylesheets:

```html
<link id="nds-theme-stylesheet" rel="stylesheet"
      href="/assets/events/Hajj/nds-theme-hajj.min.css">
<script src="/assets/events/Hajj/nds-theme-hajj.min.js"></script>
```

Keep the script tag out of `defer` and in `<head>`: it injects the event hero
slide during parse, so the slide is there in the first paint with no flash.

Delete the two lines when the event ends. That is the whole decommissioning.

## What is in here

| Path | What it is |
|------|------------|
| `nds-theme-hajj.min.css` | Compiled stylesheet |
| `nds-theme-hajj.min.js` | The pack — injects the stylesheet link, the theme token, and the hero slide |
| `src/` | Readable source for both, if you want to retheme |
| everything else | Images the pack references |

The script resolves its CSS and images relative to its own `src`, so this folder
works at any path as long as the contents stay together.

Full documentation: https://mazin-musleh.github.io/NDS-vanilla/events/hajj.html
