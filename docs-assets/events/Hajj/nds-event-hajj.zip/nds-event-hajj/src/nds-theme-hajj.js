// Hajj event theme PACK — Hayyakom welcome skin. Self-contained entry point,
// modelled on the Foundation Day pack but KEEPING THE DGA PALETTE: it only
// injects its stylesheet + marker token + a hero slide (Saudi-font title, a
// top-start Hayyakom logo, a direction-aware background). Colours stay DGA.
//
// Two ways to activate, one code path:
//   1. Downstream one-tag: a site drops a single <script src=".../nds-theme-
//      hajj.min.js"> tag. Placed synchronously in <head>, the stylesheet it
//      injects is render-blocking → themed first paint, zero FOUC (with `defer`
//      it still works, with a brief default-theme flash). The pack injects its
//      own <link>, stamps the marker token on <html data-theme>, and injects the
//      event hero slide. Deleting the tag ends the event cleanly.
//   2. Showcase switcher: _js/nds-theme.js loads this file on demand and drives
//      it via the hooks below; its own link/token writes overlap ours idempotently.
//
// Hooks contract: window.__NDS_THEME_HOOKS[THEME] = { inject, teardown }, both
// idempotent and self-contained — inject = styles + token + slide, teardown
// removes all three. Token writes are attribute-only; persistence stays the switcher's job.
//
// Per-deployment content overrides via data-* attributes on the script tag
// (all optional; bare filenames resolve against this script's own folder):
//   data-title-ar / data-title-en
//   data-description-ar / data-description-en
//   data-logo             ('' = omit the logo)
//   data-cta-url          https or path-relative only ('' = no CTA)
//   data-cta-label-ar / data-cta-label-en
//   data-cta-icon         ('' = omit)
(function () {
    'use strict';

    var THEME = 'hajj';
    var LINK_ID = 'nds-theme-stylesheet';   // shared slot: nds-theme.js LINK_ID + head.html brand path
    var SWIPER_SELECTOR = '.nds-hero-section .nds-swiper.nds-hero';
    var SLIDE_CLASS = 'nds-hajj';

    // This script ships beside its assets (…/docs-assets/events/Hajj/), so its own
    // folder is the asset base. Captured at load — currentScript is null inside
    // the later hook calls.
    var SCRIPT = document.currentScript ||
        document.querySelector('script[src*="nds-theme-hajj"]');
    var BASE = SCRIPT && SCRIPT.src ? SCRIPT.src.slice(0, SCRIPT.src.lastIndexOf('/') + 1) : '';
    var CSS_HREF = BASE + 'nds-theme-' + THEME + '.min.css';
    // The pack's own CSS, injected inline. scripts/mkevent.py prepends the
    // assignment to the minified file; read off a global rather than declared as
    // a constant here because a minifier folds a constant '' and takes the whole
    // inline branch with it as dead code. Unset (repo, or a JS rebuild after
    // mkevent) the link fallback runs -- slower, never broken.
    var CSS_TEXT = window.__NDS_EVENT_CSS || '';
    try { delete window.__NDS_EVENT_CSS; } catch (e) { window.__NDS_EVENT_CSS = void 0; }
    // mkevent.py rewrote every relative url() to this token, because an inlined
    // <style> resolves them against the document instead of the stylesheet. BASE
    // is this script's own folder, so the assets resolve wherever the pack sits.
    if (CSS_TEXT) CSS_TEXT = CSS_TEXT.split('__NDS_EVENT_BASE__').join(BASE);
    // Copied onto the injected <style> so a nonce-based CSP accepts it. Read off
    // SCRIPT, captured above -- currentScript is null inside any later callback.
    var NONCE = (SCRIPT && SCRIPT.nonce) || '';
    var DATA = SCRIPT ? SCRIPT.dataset : {};

    function pick(key, fallback) {
        return DATA[key] !== undefined ? DATA[key] : fallback;
    }
    // Reject any explicit scheme except http(s) — config lands in src/href attributes.
    function isSafeUrl(url) {
        return /^[a-z][a-z0-9+.-]*:/i.test(url) ? /^https?:/i.test(url) : true;
    }
    // Bare filename → this pack's folder; absolute URL / rooted path → verbatim.
    function resolveAssetUrl(source) {
        if (!source || !isSafeUrl(source)) return '';
        return (/^https?:/i.test(source) || source.charAt(0) === '/' || source.charAt(0) === '.') ? source : BASE + source;
    }

    // No CTA by default — a downstream site can opt in via data-cta-url.
    var ctaUrl = pick('ctaUrl', '');
    if (!isSafeUrl(ctaUrl)) {
        console.warn('NDS Hajj: data-cta-url rejected (https or path-relative only)');
        ctaUrl = '';
    }

    // ── Event content (defaults; overridden by the data-* attributes above) ──
    // Strings can be a plain value or a { ar, en } map (picked by <html lang>).
    var hero = {
        title: { ar: pick('titleAr', 'خلق رحلة روحانية خالدة'), en: pick('titleEn', 'Creating a Lasting Spiritual Journey') },
        description: {
            ar: pick('descriptionAr', 'رؤيتنا خلق رحلة روحانية خالدة تفوق تطلعات ضيوف الرحمن'),
            en: pick('descriptionEn', 'Our vision is to create a lasting spiritual journey that exceeds the expectations of the Guests of the Most Merciful.'),
        },
        logo: pick('logo', 'hayyakom.svg'),
        logoAlt: { ar: 'حياكم', en: 'Hayyakom' },
        cta: ctaUrl ? {
            url: ctaUrl,
            label: { ar: pick('ctaLabelAr', 'منصة نسك'), en: pick('ctaLabelEn', 'Nusuk Platform') },
            icon: pick('ctaIcon', ''),
        } : null,
    };
    // ─────────────────────────────────────────────────────────────────────────

    // Page language (ar | en); resolve a string or a { ar, en } field to text.
    var LANG = (document.documentElement.lang || 'en').slice(0, 2);
    function getText(value) {
        if (value && typeof value === 'object') return value[LANG] || value.en || value.ar || '';
        return value || '';
    }
    // Content is externally configurable (data-*) → escape everything interpolated.
    function escapeHtml(text) {
        return String(text).replace(/&/g, '&amp;').replace(/</g, '&lt;')
            .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    }

    function buildSlide() {
        var logoUrl = resolveAssetUrl(hero.logo);
        var logo = logoUrl
            ? '<img src="' + escapeHtml(logoUrl) + '" class="nds-hajj-logo" alt="' + escapeHtml(getText(hero.logoAlt)) + '">'
            : '';
        var description = getText(hero.description) ? '<p class="nds-section-description">' + escapeHtml(getText(hero.description)) + '</p>' : '';
        var iconUrl = hero.cta ? resolveAssetUrl(hero.cta.icon) : '';
        var cta = hero.cta
            ? '<div class="nds-section-action">' +
                '<a class="nds-btn nds-primary nds-oncolor nds-lg" href="' + escapeHtml(hero.cta.url) + '" target="_blank">' +
                  (iconUrl ? '<img src="' + escapeHtml(iconUrl) + '" class="nds-icon" width="24" height="24" alt="">' : '') +
                  '<span class="nds-label">' + escapeHtml(getText(hero.cta.label)) + '</span>' +
                '</a>' +
              '</div>'
            : '';

        var slide = document.createElement('div');
        slide.className = 'nds-swiper-slide nds-content-wrapper ' + SLIDE_CLASS;
        slide.innerHTML =
            '<div class="nds-section-body">' +
              logo +
              '<h2 class="nds-section-title">' + escapeHtml(getText(hero.title)) + '</h2>' +
              description + cta +
            '</div>';
        return slide;
    }

    // ── Stylesheet link (shared #nds-theme-stylesheet slot) ─────────────────
    // Create only if absent: the brand: path in head.html fills that slot itself —
    // leave its href (incl. ?ver=) alone. The switcher never fills it: it loads this
    // pack and nothing else, because the CSS below is already inside this file.
    // The stylesheet reaches the page inline when the build filled CSS_TEXT, and
    // as a fetched link otherwise. Inline is ~400ms of first paint on slow 4G:
    // the link costs a SECOND blocking round trip, discovered only once this
    // script has run. Either way it is skipped when LINK_ID already exists --
    // the brand: path in head.html owns that slot.
    function ensureStyles() {
        if (document.getElementById(LINK_ID)) return;
        if (document.querySelector('[data-nds-event-style]')) return;
        if (CSS_TEXT) {
            var style = document.createElement('style');
            style.setAttribute('data-nds-event-style', THEME);
            if (NONCE) style.setAttribute('nonce', NONCE);
            style.textContent = CSS_TEXT;
            document.head.appendChild(style);
            return;
        }
        if (document.readyState === 'loading') {
            // Parser-inserted = render-blocking in every browser; script-created
            // links are NOT, so appendChild alone flashes the default theme.
            document.write('<link id="' + LINK_ID + '" rel="stylesheet" href="' + CSS_HREF + '">');
            if (document.getElementById(LINK_ID)) return;
        }
        var link = document.createElement('link');
        link.rel = 'stylesheet'; link.id = LINK_ID; link.href = CSS_HREF;
        link.blocking = 'render';
        document.head.appendChild(link);
    }
    function removeStyles() {
        var link = document.getElementById(LINK_ID);
        if (link) link.remove();
        var style = document.querySelector('[data-nds-event-style="' + THEME + '"]');
        if (style) style.remove();
    }

    // ── Marker token on <html data-theme> (attribute-only, no storage) ──────
    function getTokens() {
        return (document.documentElement.getAttribute('data-theme') || '').split(/\s+/).filter(Boolean);
    }
    function writeTokens(tokens) {
        if (tokens.length) document.documentElement.setAttribute('data-theme', tokens.join(' '));
        else document.documentElement.removeAttribute('data-theme');
    }
    function addToken() {
        var tokens = getTokens();
        if (tokens.indexOf(THEME) === -1) { tokens.push(THEME); writeTokens(tokens); }
    }
    function removeToken() {
        writeTokens(getTokens().filter(function (x) { return x !== THEME; }));
    }

    // ── Hero slide ──────────────────────────────────────────────────────────
    function reinit(swiper) {
        var old = swiper.ndsSwiper || swiper._ndsSwiper; // _ndsSwiper: runtimes before 2.0
        if (old) old.destroy();
        if (!(window.NDS && NDS.Swiper)) return;
        var instance = NDS.Swiper.create(swiper);
        // A fresh instance detects its index from the re-used DOM's scroll position,
        // so it won't auto-land on the new first slide — move to it once layout settles.
        if (instance && typeof instance.goTo === 'function') {
            requestAnimationFrame(function () { instance.goTo(0); });
        }
    }

    function injectSlide() {
        var swiper = document.querySelector(SWIPER_SELECTOR);
        if (!swiper) return;
        var wrapper = swiper.querySelector('.nds-swiper-wrapper');
        if (!wrapper || wrapper.querySelector('.' + SLIDE_CLASS)) return;   // idempotent
        wrapper.insertBefore(buildSlide(), wrapper.firstChild);
        var total = parseInt(swiper.style.getPropertyValue('--total'), 10) || (wrapper.children.length - 1);
        swiper.style.setProperty('--total', String(total + 1));
        // Swiper init lives in the delegated bundle, so a sync-in-head pack always
        // wins the race and init includes the new first slide on its own pass (no
        // re-init, no goTo, no flash). But when the switcher loads this file
        // mid-session Swiper is already live → re-init to pick up the slide.
        if (swiper.hasAttribute('data-nds-swiper-initialized')) reinit(swiper);
    }

    // Sync-in-head the body doesn't exist yet at execute time: watch the parser and
    // inject the moment the hero wrapper enters the DOM (before first paint, before
    // delegated Swiper init). DOMContentLoaded is the no-hero/missed-race fallback;
    // it no-ops if the observer was already cancelled (injected or torn down).
    var observer = null;
    function cancelPending() {
        if (observer) { observer.disconnect(); observer = null; }
    }
    function scheduleSlide() {
        if (document.readyState !== 'loading') { injectSlide(); return; }
        if (observer) return;
        observer = new MutationObserver(function () {
            if (document.querySelector(SWIPER_SELECTOR + ' .nds-swiper-wrapper')) {
                cancelPending();
                injectSlide();
            }
        });
        observer.observe(document.documentElement, { childList: true, subtree: true });
        document.addEventListener('DOMContentLoaded', function () {
            if (!observer) return;
            cancelPending();
            injectSlide();
        }, { once: true });
    }

    function removeSlide() {
        var swiper = document.querySelector(SWIPER_SELECTOR);
        if (!swiper) return;
        // A loop's head clones copy the class and come first; reinit drops them.
        var slide = swiper.querySelector('.nds-swiper-slide.' + SLIDE_CLASS + ':not(.nds-swiper-clone)');
        if (!slide) return;
        slide.remove();
        var total = parseInt(swiper.style.getPropertyValue('--total'), 10) || (swiper.querySelectorAll('.nds-swiper-slide').length + 1);
        swiper.style.setProperty('--total', String(Math.max(1, total - 1)));
        if (swiper.hasAttribute('data-nds-swiper-initialized')) reinit(swiper);
    }

    // ── Hooks (own link + token + slide) + self-activation ──────────────────
    function inject() {
        ensureStyles();
        addToken();
        scheduleSlide();
    }
    function cleanup() {
        cancelPending();
        removeSlide();
        removeToken();
        removeStyles();
    }

    window.__NDS_THEME_HOOKS = window.__NDS_THEME_HOOKS || {};
    window.__NDS_THEME_HOOKS[THEME] = { inject: inject, teardown: cleanup };

    // undefined → no switcher orchestration on this page (downstream one-tag): self-activate.
    // === THEME → the switcher activated us (first-load fetch race resolved): activate.
    // anything else ('' / another theme) → user switched away mid-fetch: register hooks only.
    var active = window.__NDS_THEME_ACTIVE;
    if (active === undefined || active === THEME) {
        window.__NDS_THEME_ACTIVE = THEME;
        inject();
    }
})();
