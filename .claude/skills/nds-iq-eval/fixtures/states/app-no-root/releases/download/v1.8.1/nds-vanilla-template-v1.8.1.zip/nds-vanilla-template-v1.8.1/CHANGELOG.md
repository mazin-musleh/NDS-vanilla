# Changelog

## [1.8.1] - 2026-08-18

### Changed
- **Splitview** — the divider keeps its position across a reload.

### Migrating from v1.8.0
- Replace the runtime bundles.

## [1.8.0] - 2026-08-16

### Added
- **Ticker** — a single-line status strip for dashboards.
