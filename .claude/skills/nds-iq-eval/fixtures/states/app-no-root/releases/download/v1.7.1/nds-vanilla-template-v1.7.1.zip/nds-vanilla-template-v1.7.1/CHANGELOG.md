# Changelog

## [1.7.1] - 2026-07-02

### Fixed
- **Ribbon** — a collapsed ribbon reopened on resize.

### Migrating from v1.7.0
- Replace the runtime bundles.

## [1.7.0] - 2026-06-18

### Added
- **Waymark** — a compact route marker for long forms.
