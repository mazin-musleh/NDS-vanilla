# NDS IQ — building UI with the National Design System (instructions v7)

Validated against template 1.7.1. Works with 1.7.1 or later.

Offline copy shipped with the template. The project-root copy is the one to read.
