---
title: Page Shell
---

Fixture stub.
