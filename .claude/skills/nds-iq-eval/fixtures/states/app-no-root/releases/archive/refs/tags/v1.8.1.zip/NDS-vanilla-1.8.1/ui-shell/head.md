---
title: Document Head
---

Fixture stub.
