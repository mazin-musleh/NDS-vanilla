/* nds-core.js — fixture stub */
window.NDS=window.NDS||{};
