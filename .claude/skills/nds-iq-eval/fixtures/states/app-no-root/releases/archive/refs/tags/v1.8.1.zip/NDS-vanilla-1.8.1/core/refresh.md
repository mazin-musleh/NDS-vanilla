---
title: Refresh
---

Fixture stub.
