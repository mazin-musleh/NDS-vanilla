/* nds-modal.js — fixture stub */
