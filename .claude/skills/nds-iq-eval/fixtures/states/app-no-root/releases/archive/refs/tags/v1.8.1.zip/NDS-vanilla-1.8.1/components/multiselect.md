---
title: Multiselect
---

Fixture stub.
