# NDS Vanilla Template

Extract this folder, move its CONTENTS into your declared NDS_ROOT path and drop the wrapper.
The adoption guide lives in `NDS-IQ.md` beside this file.
